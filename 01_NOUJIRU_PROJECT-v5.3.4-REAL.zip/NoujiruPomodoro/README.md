# 脳汁ポモドーロ Android v5.3.2

HTML版をAndroid WebViewに内蔵した個人用アプリです。

- applicationId: `com.leroy.noujiru`
- versionCode: `532`
- versionName: `5.3.2`
- 固定の開発用署名鍵を使用（上書き更新用）
