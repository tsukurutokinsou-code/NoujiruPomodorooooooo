# 脳汁ポモドーロ Android v5.3.2

HTML版をAndroid WebViewに内蔵した個人用アプリです。

- applicationId: `com.leroy.noujiru`
- versionCode: `532`
- versionName: `5.3.2`
- 固定の開発用署名鍵を使用（上書き更新用）

## v5.3.4
- Wake Attack開始直後にネイティブ通知・音・バイブを停止していた処理を修正
- 通知・音・バイブは「勉強再開」操作まで継続
- Android 13以降の振動をアラーム用途として実行
- 振動機能の有無を確認してから開始


## v5.3.6
- Wake Attackの標準アラーム音を削除
- Web側の電子警告音（通称「爆撃」）のみ使用


## v5.4.0
- 山登りチャレンジ最小安定版を追加
- 山・1〜20日の期限を選択し、登頂まで変更不可
- 記録済み集中時間を進捗へ加算
- 登頂EXPと期限ボーナスを追加
- 期限切れ時は挑戦終了（ペットペナルティは次段階で実装）


## v5.5.0 KONO山
- KONO山（10時間・1日固定）を追加
- 進捗に応じて人物画像が下から表示
- 登頂報酬：プレイヤー12,000EXP、ペット1,000EXP

## v5.7.1 FULL_SYNC_FIX
- Android starts a Firestore state listener after login/page load.
- Android refreshes cloud state on resume.
- Manual sync fetches remote state before merging/uploading.
- Initial learning/sleep counters are clean while subject/material inputs remain editable.

## v5.7.2 SAFE_MERGE_SYNC
- Firestore transaction merges cloud and local state before every write.
- XP, totals, counts, combo, sleep totals and pet growth cannot be lowered by another device.
- Logs are unioned by ID.
- A pre-sync local backup is stored before applying cloud state.
