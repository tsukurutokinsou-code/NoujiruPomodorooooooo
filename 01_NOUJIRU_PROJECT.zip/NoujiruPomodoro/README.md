# 脳汁ポモドーロ Android v5.3.2

HTML版をAndroid WebViewに内蔵した個人用アプリです。

- applicationId: `com.leroy.noujiru`
- versionCode: `532`
- versionName: `5.3.2`
- 固定の開発用署名鍵を使用（上書き更新用）

## v5.3.4
- Wake Attack開始直後にネイティブ通知・音・バイブを停止していた処理を修正
- 通知・音・バイブは「勉強再開」操作まで継続
- Android 13以降の振動をアラーム用途として実行
- 振動機能の有無を確認してから開始
