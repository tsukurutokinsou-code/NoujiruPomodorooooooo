package com.leroy.noujiru;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class WakeupAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, WakeupService.class)
                .putExtra("sound", intent.getBooleanExtra("sound", true))
                .putExtra("vibrate", intent.getBooleanExtra("vibrate", true));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
