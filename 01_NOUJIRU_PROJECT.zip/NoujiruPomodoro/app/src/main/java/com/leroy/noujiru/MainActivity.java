package com.leroy.noujiru;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int RC_GOOGLE_SIGN_IN = 560;
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private GoogleSignInClient googleSignInClient;
    private final Gson gson = new Gson();

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 533);
        }

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, signInOptions);

        webView = findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidWakeBridge(this), "AndroidWake");
        webView.addJavascriptInterface(new AndroidCloudBridge(), "AndroidCloud");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                sendAuthStateToWeb();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private DocumentReference stateRef(FirebaseUser user) {
        return firestore.collection("users").document(user.getUid())
                .collection("app").document("state");
    }

    private void eval(String javascript) {
        runOnUiThread(() -> webView.evaluateJavascript(javascript, null));
    }

    private String jsString(String value) {
        return gson.toJson(value == null ? "" : value);
    }

    private void sendStatus(String message, boolean ok) {
        eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onStatus(" + jsString(message) + "," + ok + ");");
    }

    private void sendAuthStateToWeb() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onAuth(null);");
            return;
        }
        Map<String, Object> info = new HashMap<>();
        info.put("uid", user.getUid());
        info.put("displayName", user.getDisplayName());
        info.put("email", user.getEmail());
        info.put("photoUrl", user.getPhotoUrl() == null ? null : user.getPhotoUrl().toString());
        eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onAuth(" + jsString(gson.toJson(info)) + ");");
    }

    private void startGoogleSignIn() {
        startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE_SIGN_IN) return;
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
            auth.signInWithCredential(credential).addOnCompleteListener(this, result -> {
                if (result.isSuccessful()) {
                    sendAuthStateToWeb();
                    sendStatus("Googleログイン成功。同期します", true);
                    fetchRemoteState();
                } else {
                    String detail = result.getException() == null ? "不明なエラー" : result.getException().getMessage();
                    sendStatus("Firebaseログイン失敗：" + detail, false);
                }
            });
        } catch (ApiException e) {
            sendStatus("Googleログイン失敗（コード " + e.getStatusCode() + "）", false);
        }
    }

    private void fetchRemoteState() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            sendAuthStateToWeb();
            return;
        }
        stateRef(user).get().addOnSuccessListener(snapshot -> {
            Object remote = snapshot.get("state");
            String json = remote == null ? null : gson.toJson(remote);
            eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onRemote(" + (json == null ? "null" : jsString(json)) + ");");
        }).addOnFailureListener(e -> sendStatus("データ取得失敗：" + e.getMessage(), false));
    }

    private void uploadState(String json) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            sendStatus("Googleログインが必要です", false);
            return;
        }
        try {
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> state = gson.fromJson(json, type);
            Map<String, Object> payload = new HashMap<>();
            payload.put("state", state);
            payload.put("updatedAt", System.currentTimeMillis());
            payload.put("deviceId", "android-" + Build.MODEL);
            stateRef(user).set(payload, SetOptions.merge())
                    .addOnSuccessListener(v -> sendStatus("同期済み", true))
                    .addOnFailureListener(e -> sendStatus("同期待機：" + e.getMessage(), false));
        } catch (Exception e) {
            sendStatus("同期データ変換失敗：" + e.getMessage(), false);
        }
    }

    private final class AndroidCloudBridge {
        @JavascriptInterface
        public void signIn() {
            runOnUiThread(MainActivity.this::startGoogleSignIn);
        }

        @JavascriptInterface
        public void signOut() {
            runOnUiThread(() -> auth.signOut());
            googleSignInClient.signOut().addOnCompleteListener(task -> {
                sendAuthStateToWeb();
                sendStatus("ログアウトしました", true);
            });
        }

        @JavascriptInterface
        public void requestAuthState() {
            sendAuthStateToWeb();
        }

        @JavascriptInterface
        public void fetchState() {
            fetchRemoteState();
        }

        @JavascriptInterface
        public void uploadState(String json) {
            MainActivity.this.uploadState(json);
        }
    }

    private static class AndroidWakeBridge {
        private final Context context;

        AndroidWakeBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @JavascriptInterface
        public void scheduleWakeup(int seconds, boolean sound, boolean vibrate) {
            WakeupScheduler.schedule(context, Math.max(1, seconds), sound, vibrate);
        }

        @JavascriptInterface
        public void cancelWakeup() {
            WakeupScheduler.cancel(context);
        }

        @JavascriptInterface
        public void triggerWakeup(boolean sound, boolean vibrate) {
            Intent service = new Intent(context, WakeupService.class)
                    .putExtra("sound", sound)
                    .putExtra("vibrate", vibrate);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        }

        @JavascriptInterface
        public void stopWakeup() {
            WakeupScheduler.cancel(context);
            context.stopService(new Intent(context, WakeupService.class));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
