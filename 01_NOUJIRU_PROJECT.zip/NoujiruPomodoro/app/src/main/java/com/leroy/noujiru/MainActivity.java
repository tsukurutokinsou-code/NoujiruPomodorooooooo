package com.leroy.noujiru;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int RC_GOOGLE_SIGN_IN = 560;
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private GoogleSignInClient googleSignInClient;
    private final Gson gson = new Gson();

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 533);
        }

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, signInOptions);

        webView = findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidWakeBridge(this), "AndroidWake");
        webView.addJavascriptInterface(new AndroidCloudBridge(), "AndroidCloud");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                sendAuthStateToWeb();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private DocumentReference stateRef(FirebaseUser user) {
        return firestore.collection("users").document(user.getUid())
                .collection("app").document("state");
    }

    private DocumentReference logRef(FirebaseUser user, String id) {
        return firestore.collection("users").document(user.getUid())
                .collection("logs").document(id);
    }

    private void eval(String javascript) {
        runOnUiThread(() -> webView.evaluateJavascript(javascript, null));
    }

    private String jsString(String value) {
        return gson.toJson(value == null ? "" : value);
    }

    private void sendStatus(String message, boolean ok) {
        eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onStatus(" + jsString(message) + "," + ok + ");");
    }

    private void sendAuthStateToWeb() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onAuth(null);");
            return;
        }
        Map<String, Object> info = new HashMap<>();
        info.put("uid", user.getUid());
        info.put("displayName", user.getDisplayName());
        info.put("email", user.getEmail());
        info.put("photoUrl", user.getPhotoUrl() == null ? null : user.getPhotoUrl().toString());
        eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onAuth(" + jsString(gson.toJson(info)) + ");");
    }

    private void startGoogleSignIn() {
        startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE_SIGN_IN) return;
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
            auth.signInWithCredential(credential).addOnCompleteListener(this, result -> {
                if (result.isSuccessful()) {
                    sendAuthStateToWeb();
                    sendStatus("Googleログイン成功。同期します", true);
                    fetchRemoteState();
                } else {
                    String detail = result.getException() == null ? "不明なエラー" : result.getException().getMessage();
                    sendStatus("Firebaseログイン失敗：" + detail, false);
                }
            });
        } catch (ApiException e) {
            sendStatus("Googleログイン失敗（コード " + e.getStatusCode() + "）", false);
        }
    }

    private void fetchRemoteState() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            sendAuthStateToWeb();
            return;
        }
        stateRef(user).get().addOnSuccessListener(snapshot -> {
            Object remote = snapshot.get("state");
            String json = remote == null ? null : gson.toJson(remote);
            eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onRemote(" + (json == null ? "null" : jsString(json)) + ");");
        }).addOnFailureListener(e -> sendStatus("データ取得失敗：" + e.getMessage(), false));
    }


    private double number(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        try { return value == null ? 0d : Double.parseDouble(String.valueOf(value)); }
        catch (Exception ignored) { return 0d; }
    }

    private Object maxNumber(Object a, Object b) {
        double x = number(a), y = number(b), max = Math.max(x, y);
        if (a instanceof Long || a instanceof Integer || b instanceof Long || b instanceof Integer) {
            return (long) max;
        }
        return max;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> asMap(Object value) {
        return value instanceof Map ? new HashMap<>((Map<String, Object>) value) : new HashMap<>();
    }

    @SuppressWarnings("unchecked")
    private List<Object> asList(Object value) {
        return value instanceof List ? new ArrayList<>((List<Object>) value) : new ArrayList<>();
    }

    private Map<String, Object> mergeLogs(Object remoteValue, Object localValue) {
        Map<String, Object> remote = asMap(remoteValue);
        Map<String, Object> local = asMap(localValue);
        Map<String, Object> out = new HashMap<>();
        Set<String> days = new HashSet<>();
        days.addAll(remote.keySet());
        days.addAll(local.keySet());

        for (String day : days) {
            LinkedHashMap<String, Object> byId = new LinkedHashMap<>();
            for (Object item : asList(remote.get(day))) {
                Map<String, Object> log = asMap(item);
                Object id = log.get("id");
                if (id != null) byId.put(String.valueOf(id), log);
            }
            for (Object item : asList(local.get(day))) {
                Map<String, Object> log = asMap(item);
                Object id = log.get("id");
                if (id != null) byId.put(String.valueOf(id), log);
            }
            out.put(day, new ArrayList<>(byId.values()));
        }
        return out;
    }

    private Map<String, Object> mergePets(Object remoteValue, Object localValue) {
        Map<String, Object> remote = asMap(remoteValue);
        Map<String, Object> local = asMap(localValue);
        Map<String, Object> out = new HashMap<>();
        Set<String> types = new HashSet<>();
        types.addAll(remote.keySet());
        types.addAll(local.keySet());

        for (String type : types) {
            Map<String, Object> r = asMap(remote.get(type));
            Map<String, Object> l = asMap(local.get(type));
            Map<String, Object> pet = new HashMap<>(r);
            pet.putAll(l);
            pet.put("xp", maxNumber(r.get("xp"), l.get("xp")));
            pet.put("aff", maxNumber(r.get("aff"), l.get("aff")));
            pet.put("energy", maxNumber(r.get("energy"), l.get("energy")));
            out.put(type, pet);
        }
        return out;
    }

    private Map<String, Object> safeMergeState(Map<String, Object> remote, Map<String, Object> local) {
        Map<String, Object> out = new HashMap<>(remote);
        out.putAll(local);

        String[] monotonic = {
                "xp", "sets", "mins", "combo", "best", "todayMins",
                "sleepCount", "sleepMinutes", "mountainSuccesses"
        };
        for (String key : monotonic) {
            out.put(key, maxNumber(remote.get(key), local.get(key)));
        }

        out.put("logs", mergeLogs(remote.get("logs"), local.get("logs")));
        out.put("pets", mergePets(remote.get("pets"), local.get("pets")));

        // Never replace a non-empty active pet/name with an empty value.
        Object localActive = local.get("activePet");
        Object remoteActive = remote.get("activePet");
        if (localActive == null || String.valueOf(localActive).isEmpty()) {
            out.put("activePet", remoteActive);
        }

        return out;
    }

    private void uploadState(String json) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            sendStatus("Googleログインが必要です", false);
            return;
        }
        try {
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> localState = gson.fromJson(json, type);
            DocumentReference ref = stateRef(user);

            firestore.runTransaction(transaction -> {
                DocumentSnapshot snapshot = transaction.get(ref);
                Map<String, Object> remoteState = asMap(snapshot.get("state"));
                Map<String, Object> merged = safeMergeState(remoteState, localState);

                Map<String, Object> payload = new HashMap<>();
                payload.put("state", merged);
                payload.put("updatedAt", System.currentTimeMillis());
                payload.put("deviceId", "android-" + Build.MODEL);
                transaction.set(ref, payload, SetOptions.merge());
                return merged;
            }).addOnSuccessListener(merged -> {
                String mergedJson = gson.toJson(merged);
                eval("window.NoujiruNativeCloud&&window.NoujiruNativeCloud.onRemote(" + jsString(mergedJson) + ");");
                sendStatus("安全統合済み", true);
            }).addOnFailureListener(e -> sendStatus("同期待機：" + e.getMessage(), false));
        } catch (Exception e) {
            sendStatus("同期データ変換失敗：" + e.getMessage(), false);
        }
    }

    private void uploadLog(String json) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            sendStatus("Googleログインが必要です", false);
            return;
        }
        try {
            Type type = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> log = gson.fromJson(json, type);
            String id = String.valueOf(log.get("id"));
            if (id == null || id.isEmpty() || "null".equals(id)) throw new IllegalArgumentException("ログIDがありません");
            log.put("updatedAt", System.currentTimeMillis());
            logRef(user, id).set(log, SetOptions.merge())
                    .addOnFailureListener(e -> sendStatus("ログ同期待機：" + e.getMessage(), false));
        } catch (Exception e) {
            sendStatus("ログ変換失敗：" + e.getMessage(), false);
        }
    }

    private void deleteLog(String id) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null || id == null || id.isEmpty()) return;
        logRef(user, id).delete()
                .addOnFailureListener(e -> sendStatus("ログ削除同期待機：" + e.getMessage(), false));
    }

    private final class AndroidCloudBridge {
        @JavascriptInterface
        public void signIn() {
            runOnUiThread(MainActivity.this::startGoogleSignIn);
        }

        @JavascriptInterface
        public void signOut() {
            runOnUiThread(() -> {
                auth.signOut();
            });
            googleSignInClient.signOut().addOnCompleteListener(task -> {
                sendAuthStateToWeb();
                sendStatus("ログアウトしました", true);
            });
        }

        @JavascriptInterface
        public void requestAuthState() {
            sendAuthStateToWeb();
        }

        @JavascriptInterface
        public void fetchState() {
            fetchRemoteState();
        }

        @JavascriptInterface
        public void uploadState(String json) {
            MainActivity.this.uploadState(json);
        }

        @JavascriptInterface
        public void uploadLog(String json) {
            MainActivity.this.uploadLog(json);
        }

        @JavascriptInterface
        public void deleteLog(String id) {
            MainActivity.this.deleteLog(id);
        }
    }

    private static class AndroidWakeBridge {
        private final Context context;

        AndroidWakeBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @JavascriptInterface
        public void scheduleWakeup(int seconds, boolean sound, boolean vibrate) {
            WakeupScheduler.schedule(context, Math.max(1, seconds), sound, vibrate);
        }

        @JavascriptInterface
        public void cancelWakeup() {
            WakeupScheduler.cancel(context);
        }

        @JavascriptInterface
        public void triggerWakeup(boolean sound, boolean vibrate) {
            Intent service = new Intent(context, WakeupService.class)
                    .putExtra("sound", sound)
                    .putExtra("vibrate", vibrate);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        }

        @JavascriptInterface
        public void stopWakeup() {
            WakeupScheduler.cancel(context);
            context.stopService(new Intent(context, WakeupService.class));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
