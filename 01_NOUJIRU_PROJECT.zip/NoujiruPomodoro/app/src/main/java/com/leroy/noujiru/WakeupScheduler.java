package com.leroy.noujiru;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

public final class WakeupScheduler {
    private static final int REQUEST_CODE = 5321;

    private WakeupScheduler() {}

    private static PendingIntent pendingIntent(Context context, boolean sound, boolean vibrate) {
        Intent intent = new Intent(context, WakeupAlarmReceiver.class)
                .putExtra("sound", sound)
                .putExtra("vibrate", vibrate);
        return PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    public static void schedule(Context context, int seconds, boolean sound, boolean vibrate) {
        cancel(context);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long triggerAt = SystemClock.elapsedRealtime() + seconds * 1000L;
        PendingIntent operation = pendingIntent(context, sound, vibrate);
        try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, operation);
        } catch (SecurityException ignored) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, operation);
        }
    }

    public static void cancel(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, WakeupAlarmReceiver.class);
        PendingIntent operation = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (operation != null) {
            alarmManager.cancel(operation);
            operation.cancel();
        }
    }
}
