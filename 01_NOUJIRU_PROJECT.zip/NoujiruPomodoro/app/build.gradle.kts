plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.leroy.noujiru"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.leroy.noujiru"
        minSdk = 24
        targetSdk = 35
        versionCode = 560
        versionName = "5.6.0"
    }

    signingConfigs {
        create("noujiruStable") {
            storeFile = rootProject.file("keystore/noujiru-dev.jks")
            storePassword = "noujiru532"
            keyAlias = "noujiru"
            keyPassword = "noujiru532"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("noujiruStable")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.android.gms:play-services-auth:21.6.0")
    implementation("com.google.code.gson:gson:2.13.1")
}
