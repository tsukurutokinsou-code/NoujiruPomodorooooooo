plugins {
    id("com.android.application")
}

android {
    namespace = "com.leroy.noujiru"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.leroy.noujiru"
        minSdk = 24
        targetSdk = 35
        versionCode = 551
        versionName = "5.5.1"
    }

    signingConfigs {
        create("noujiruStable") {
            storeFile = rootProject.file("keystore/noujiru-dev.jks")
            storePassword = "noujiru532"
            keyAlias = "noujiru"
            keyPassword = "noujiru532"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("noujiruStable")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
