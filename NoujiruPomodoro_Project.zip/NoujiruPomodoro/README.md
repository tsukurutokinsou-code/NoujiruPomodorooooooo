# 脳汁ポモドーロ v5.3.2 — Android

HTML版をAndroid WebViewに内蔵した、完全オフラインの個人用APKプロジェクトです。

## 内容
- ペット育成・EXP・コンボ
- NPv5セーブコード / NLv1学習ログ
- Wake Attack（音・バイブ・警告画面）
- localStorage保存
- 同一署名による上書き更新

## GitHub Actions
リポジトリ直下に `NoujiruPomodoro_Project.zip` を置き、
`.github/workflows/build-apk.yml` を配置するとAPKが作成されます。

完成物はActionsの実行結果の下部にある **Artifacts** から取得します。
ダウンロードされるZIPの中に `NoujiruPomodoro-v5.3.2.apk` が入ります。

## 更新時
- `applicationId` は `com.leroy.noujiru` のままにする
- `keystore/noujiru-dev.jks` を消さない
- `versionCode` を前回より大きくする
- `versionName` を更新する

この署名鍵は個人用・サイドロード更新用です。Play Store公開用の秘密鍵としては使用しないでください。
